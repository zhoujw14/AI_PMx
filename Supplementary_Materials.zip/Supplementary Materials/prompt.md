You are an expert AI assistant. Your task is to generate a high-quality response to the User Prompt below. Your goal is to maximize your score according to the Evaluation Rubric.

**User Prompt:**
{Model Prompt}

**Evaluation Rubric:**
# Rubric for NONMEM codes
## Level 1. Include the essential NONMEM control stream blocks
$PROB, $INPUT, $DATA, $SUBROUTINES, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION (or the shorthand $EST), $COVARIANCE (or $COV), and $TABLE. 

## Level 2: Ensure the correct relationship between THETA and ETA is included
Ensure the correct relationship between THETA and ETA is included. For each ETA(n), there should be a corresponding line in the $PK block, such as: 

```
KA = THETA(1) * EXP(ETA(1)) 
```

## Level 3: $SUBROUTINE, $DES, $PK and parameters setting follow the rules in this table:
$SUBROUTINE, $DES, $PK and parameters setting follow the rules in this table: 

| Model Type | Compartments                                                   | TRANS Subroutine               | Basic Parameters                                                                            | Model Description                                                               |
| :--------- | :------------------------------------------------------------- | :----------------------------- | :------------------------------------------------------------------------------------------ | :------------------------------------------------------------------------------ |
| ADVAN1     | 1 = CENTRAL2 = OUTPUT                                          | TRANS1TRANS2                   | "K, VCL, V"                                                                                 | One-compartment linear model                                                    |
| ADVAN2     | 1 = DEPOT2 = CENTRAL3 = OUTPUT                                 | TRANS1TRANS2                   | "KA, KCL, V, KA"                                                                            | One-compartment linear model with first-order absorption                        |
| ADVAN3     | 1 = CENTRAL2 = PERIPHERAL3 = OUTPUT                            | TRANS1TRANS3TRANS4TRANS5TRANS6 | "K, K12, K21CL, V, Q, VSSCL, V1, Q, V2AOB, ALPHA, BETAALPHA, BETA, K21"                     | Two-compartment linear mammillary model                                         |
| ADVAN4     | 1 = DEPOT2 = CENTRAL3 = PERIPHERAL4 = OUTPUT                   | TRANS1TRANS3TRANS4TRANS5TRANS6 | "KA, K, K23, K32CL, V, Q, VSS, KACL, V2, Q, V3, KAAOB, ALPHA, BETA, KAALPHA, BETA, K32, KA" | Two-compartment linear mammillary model with first-order absorption             |
| ADVAN10    | 1 = CENTRAL2 = OUTPUT                                          | TRANS1                         | "VM, KM"                                                                                    | One-compartment model with Michaelis–Menten elimination                         |
| ADVAN11    | 1 = CENTRAL2 = PERIPHERAL 13 = PERIPHERAL 24 = OUTPUT          | TRANS1TRANS4TRANS6             | "K, K12, K21, K13, K31CL, V1, Q2, V2, Q3, V3ALPHA, BETA, GAMMA, K21, K31"                   | Three-compartment linear mammillary model                                       |
| ADVAN12    | 1 = DEPOT2 = CENTRAL3 = PERIPHERAL 14 = PERIPHERAL 25 = OUTPUT | TRANS1TRANS4TRANS6             | "KA, K, K23, K32, K24, K42CL, V2, Q3, V3, Q4, V4, KAALPHA, BETA, GAMMA, KA, K32, K42"       | Three-compartment linear mammillary model with first-order absorption           |
| ADVAN5     | GENERAL LINEAR MODEL                                           | TRANS1                         | —                                                                                           | General linear model (real or complex eigenvalues)                              |
| ADVAN7     | GENERAL LINEAR MODEL WITH REAL EIGENVALUES                     | TRANS1                         | —                                                                                           | General linear model with real eigenvalues                                      |
| ADVAN6     | GENERAL NONLINEAR MODEL (RK56 ODE solver)                      | TRANS1                         | —                                                                                           | General nonlinear model (DVERK1)                                                |
| ADVAN8     | GENERAL NONLINEAR MODEL (GEAR ODE solver)                      | TRANS1                         | —                                                                                           | General nonlinear model with stiff differential equations (DGEAR1)              |
| ADVAN9     | GENERAL NONLINEAR MODEL (LSODI ODE solver with ADE)            | TRANS1                         | —                                                                                           | General nonlinear model with equilibrium compartments (LSODI1)                  |
| ADVAN13    | GENERAL NONLINEAR MODEL (LSODA ODE solver)                     | TRANS1                         | —                                                                                           | General nonlinear model with stiff or non-stiff differential equations (LSODA)  |
| ADVAN14    | GENERAL NONLINEAR MODEL (CVODES ODE solver)                    | TRANS1                         | —                                                                                           | General nonlinear model with stiff or non-stiff differential equations (CVODES) |
| ADVAN15    | GENERAL NONLINEAR MODEL (IDAS ODE and ADE solver)              | TRANS1                         | —                                                                                           | General nonlinear model with equilibrium compartments (IDAS)                    |

**How Your Response Will Be Scored:**
An expert evaluator will assess your response using the rubric and an additive scoring system. To get the highest score, you should aim to meet the criteria for as many levels as possible.

Your response will be evaluated independently against the criteria for Level 1, Level 2, and Level 3.
You will be assigned points for each set of level criteria that your response successfully meets:
Level 1 criteria met = +1 point
Level 2 criteria met = +2 points
Level 3 criteria met = +3 points
The final score is the sum of all the points you earn. A perfect response that meets all criteria would receive a Final Score: 6 (1 + 2 + 3).

**Your Task:**
Generate a response that best addresses the User Prompt while fulfilling the criteria in the Evaluation Rubric to achieve the highest possible score.

Please provide your response:
