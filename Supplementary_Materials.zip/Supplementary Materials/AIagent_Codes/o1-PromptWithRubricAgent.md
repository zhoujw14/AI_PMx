# ID: 0
## Difficulty: 1
## Prompt
Write a one-compartment, first-order absorption, linear clearance NONMEM model

## Prediction
$PROB  One-compartment model with first-order absorption and linear elimination

$INPUT ID TIME DV AMT RATE CMT EVID MDV
;  ID   = Subject ID
;  TIME = Time
;  DV   = Dependent variable (concentration)
;  AMT  = Dose amount
;  RATE = Infusion rate (0 for bolus)
;  CMT  = Compartment number
;  EVID = Event ID (dose=1)
;  MDV  = Missing dependent variable flag (0=observation, 1=no observation)

$DATA  your_data.csv IGNORE=@
;  Replace "your_data.csv" with the actual dataset filename

$SUBROUTINES ADVAN2 TRANS2
;  ADVAN2: One compartment with first-order absorption
;  TRANS2: Parameterization for KA and K

$PK
;  THETA(1) = Typical value for KA
;  THETA(2) = Typical value for CL
;  THETA(3) = Typical value for V
KA = THETA(1)*EXP(ETA(1))
CL = THETA(2)*EXP(ETA(2))
V  = THETA(3)*EXP(ETA(3))
K  = CL/V   ; Elimination rate constant

$ERROR
;  Proportional error model example
IPRED = F
W     = IPRED
IRES  = DV - IPRED
IWRES = IRES / W

$THETA 
(0.5)  ; Typical KA
(10)   ; Typical CL
(100)  ; Typical V

$OMEGA 0.1  ; Variance of ETA(1) on KA
$OMEGA 0.1  ; Variance of ETA(2) on CL
$OMEGA 0.1  ; Variance of ETA(3) on V

$SIGMA 0.1  ; Proportional residual error variance

$ESTIMATION MAXEVAL=9999 PRINT=5 METHOD=1
;  METHOD=1: First-order conditional estimation (FOCE)

$COVARIANCE
;  Computes standard errors and covariance matrix

$TABLE ID TIME DV IPRED IRES IWRES
ONEHEADER NOPRINT FILE=tab_res.csv
;  Outputs table of results to "tab_res.csv"
## Evaluation
First, let’s check for each level of the rubric:

• Level 1 (essential control stream blocks):  
  The prediction includes all of the following:  
  $PROB, $INPUT, $DATA, $SUBROUTINES, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION, $COVARIANCE, and $TABLE.  
  ⇒ Meets Level 1.  

• Level 2 (correct relationship between THETA and ETA):  
  In the $PK block, we see:  
    KA = THETA(1)*EXP(ETA(1))  
    CL = THETA(2)*EXP(ETA(2))  
    V  = THETA(3)*EXP(ETA(3))  
  This is exactly the proper way to handle interindividual variability (using ETA) around the typical values (THETA).  
  ⇒ Meets Level 2.

• Level 3 ($SUBROUTINES, $PK setup consistent with model type):  
  The chosen subroutine ADVAN2 ( TRANS2 ) is correct for a one-compartment model with first-order absorption. The parameter definitions (KA, CL, V, and K = CL/V) match the standard one-compartment, first-order absorption framework.  
  ⇒ Meets Level 3.

Since the model meets all three levels, we add up the points:  
Level 1 = 1 point  
Level 2 = 2 points  
Level 3 = 3 points  

Final Score: 6
---

# ID: 1
## Difficulty: 1
## Prompt
Write a two-compartment, first-order absorption, linear clearance NONMEM model

## Prediction
$PROB  Two-compartment model with first-order absorption and linear clearance

$INPUT  ID TIME DV AMT EVID CMT MDV
; Assuming columns: 
;   ID   = Subject identifier
;   TIME = Time of observation or dosing
;   DV   = Dependent variable (concentration)
;   AMT  = Administered dose amount
;   EVID = Event ID (0=observation, 1=dose, etc.)
;   CMT  = Compartment number
;   MDV  = Missing dependent variable flag

$DATA  data.csv IGNORE=#  ; Replace with actual data file and ignore character

$SUBROUTINE  ADVAN4  TRANS4
; ADVAN4/TRANS4 is the built-in two-compartment model with first-order absorption

$PK
; --- Structural Parameters with Inter-Individual Variability ---
KA   = THETA(1) * EXP(ETA(1))   ; First-order absorption rate constant
CL   = THETA(2) * EXP(ETA(2))   ; Clearance
V2   = THETA(3) * EXP(ETA(3))   ; Central volume of distribution
Q    = THETA(4) * EXP(ETA(4))   ; Intercompartmental clearance
V3   = THETA(5) * EXP(ETA(5))   ; Peripheral volume of distribution

; --- Derived Rate Constants ---
K10  = CL / V2
K12  = Q  / V2
K21  = Q  / V3

; --- Central Compartment Scaling ---
S2   = V2

$ERROR
; IPRED is the model-predicted concentration (F)
IPRED = F
IRES  = DV - IPRED
; You may use a different definition for SD here, e.g., SD = IPRED*ERR(1) + ERR(2). 
; For simplicity, we split into proportional and additive error:
Y = IPRED * (1 + ERR(1)) + ERR(2)

$THETA
(0.5)   ; THETA(1)  Typical value of KA
(10)    ; THETA(2)  Typical value of CL
(50)    ; THETA(3)  Typical value of V2
(20)    ; THETA(4)  Typical value of Q
(200)   ; THETA(5)  Typical value of V3

$OMEGA
0.1     ; IIV variance on KA (ETA(1))
0.2     ; IIV variance on CL (ETA(2))
0.3     ; IIV variance on V2 (ETA(3))
0.4     ; IIV variance on Q  (ETA(4))
0.5     ; IIV variance on V3 (ETA(5))

$SIGMA
0.1     ; Proportional residual error
0.05    ; Additive residual error

$ESTIMATION  MAXEVAL=999 METHOD=1 POSTHOC
$COVARIANCE

$TABLE  ID TIME DV IPRED IRES 
       NOPRINT ONEHEADER FILE=results_tab.csv
## Evaluation
Evaluation:

• Level 1 (Essential NONMEM blocks):  
  The prediction includes all of the key control stream blocks ($PROB, $INPUT, $DATA, $SUBROUTINE, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION, $COVARIANCE, and $TABLE).  
  → Pass (1 point)

• Level 2 (Correct THETA-ETA relationships):  
  Each parameter (KA, CL, V2, Q, V3) has the form THETA(n)*EXP(ETA(n)), satisfying the typical exponential inter-individual variability structure.  
  → Pass (2 points)

• Level 3 (Correct subroutines and parameterization for two-compartment, first-order absorption):  
  The code uses $SUBROUTINE ADVAN4 TRANS4 and correctly sets K10 = CL/V2, K12 = Q/V2, K21 = Q/V3, and includes first-order absorption (KA). This matches a standard two-compartment model with first-order absorption.  
  → Pass (3 points)

Total score = 1 (Level 1) + 2 (Level 2) + 3 (Level 3) = 6

Final Score: 6
---

# ID: 2
## Difficulty: 2
## Prompt
Write a three-compartment, first-order absorption, linear clearance NONMEM model

## Prediction
$PROB Three‐compartment model with first‐order absorption and linear clearance

$INPUT ID TIME DV AMT EVID MDV
; Include any other columns as necessary (e.g., CMT, WT), but at minimum these.

$DATA mydata.csv IGNORE=C
; Replace "mydata.csv" and IGNORE character as needed.

$SUBROUTINE ADVAN12 TRANS4
; ADVAN12 is the 3‐compartment model with first‐order absorption
; TRANS4 is a parameter transform suitable for typical clearance/volume parameterizations

$PK
; Typical values (THETA) with exponential inter‐individual variability (ETA)

KA    = THETA(1)*EXP(ETA(1)) ; Absorption rate constant
CL    = THETA(2)*EXP(ETA(2)) ; Clearance
V2    = THETA(3)*EXP(ETA(3)) ; Central volume
Q3    = THETA(4)*EXP(ETA(4)) ; Intercompartmental CL to/from peripheral 1
V3    = THETA(5)*EXP(ETA(5)) ; Peripheral volume 1
Q4    = THETA(6)*EXP(ETA(6)) ; Intercompartmental CL to/from peripheral 2
V4    = THETA(7)*EXP(ETA(7)) ; Peripheral volume 2

$ERROR
IPRED = F
IRES  = DV - IPRED
IWRES = IRES      ; or define a weighting scheme if desired
Y     = IPRED + ERR(1)

$THETA
(0, 0.5)   ; KA
(0, 10)    ; CL
(0, 50)    ; V2
(0, 5)     ; Q3
(0, 100)   ; V3
(0, 3)     ; Q4
(0, 150)   ; V4

$OMEGA 0.1 ; IIV on KA
$OMEGA 0.1 ; IIV on CL
$OMEGA 0.1 ; IIV on V2
$OMEGA 0.1 ; IIV on Q3
$OMEGA 0.1 ; IIV on V3
$OMEGA 0.1 ; IIV on Q4
$OMEGA 0.1 ; IIV on V4

$SIGMA 0.05

$EST MAXEVAL=9999 METHOD=1 NOABORT
$COV

$TABLE ID TIME DV IPRED IRES IWRES ONEHEADER NOPRINT FILE=tabout.csv
; Adjust table options and file name as needed.
## Evaluation
Analysis:

1) Level 1 (Essential Control-Stream Blocks):  
   The prediction includes all the essential blocks:  
   • $PROB  
   • $INPUT  
   • $DATA  
   • $SUBROUTINE  
   • $PK  
   • $ERROR  
   • $THETA  
   • $OMEGA  
   • $SIGMA  
   • $EST (Estimation)  
   • $COV (Covariance)  
   • $TABLE  

   → This satisfies Level 1 (1 point).

2) Level 2 (Correct THETA–ETA Structure):  
   In the $PK block, each model parameter is written as:  
   KA = THETA(1)*EXP(ETA(1))  
   CL = THETA(2)*EXP(ETA(2))  
   V2 = THETA(3)*EXP(ETA(3))  
   Q3 = THETA(4)*EXP(ETA(4))  
   V3 = THETA(5)*EXP(ETA(5))  
   Q4 = THETA(6)*EXP(ETA(6))  
   V4 = THETA(7)*EXP(ETA(7))  

   Each THETA(·) indeed has an accompanying EXP(ETA(·)), satisfying the exponential interindividual variability structure.  

   → This meets Level 2 (2 additional points; total so far = 3).

3) Level 3 (Correct Use of $SUBROUTINE, $PK, and Parameterization for a Three-Compartment Model with First-Order Absorption):  
   • The control stream uses $SUBROUTINE ADVAN12 TRANS4, which is a standard NONMEM library routine for a three-compartment mammillary model with first-order absorption (one depot plus two peripheral compartments).  
   • The code sets 7 THETAs (KA, CL, V2, Q3, V3, Q4, V4), consistent with a clearance/volume parameterization for two peripheral compartments.  
   • Although some users choose TRANS6 for a three-compartment model, in practice TRANS4 can be valid for certain clearance parameterizations under ADVAN12.  
   • The code therefore aligns well with a three-compartment model plus a depot (first-order absorption).  

   → This satisfies Level 3 (3 additional points; total now = 6).

Conclusion:  
The prediction meets all rubric criteria—Levels 1, 2, and 3.  

Final Score: 6  
---

# ID: 3
## Difficulty: 1
## Prompt
Write a one-compartment, first-order absorption, nonlinear clearance NONMEM model

## Prediction
$PROB  One-compartment, first-order absorption, nonlinear (Michaelis–Menten) clearance model

$INPUT ID TIME DV AMT EVID MDV
; Make sure your data file includes these columns in the correct format.

$DATA  mydata.csv IGNORE=C
; Replace "mydata.csv" and IGNORE=C with the actual data file and any rules you need.

$SUBROUTINES ADVAN6 TRANS1
; Using a general nonlinear model with the DVERK solver (ADVAN6) and TRANS1.

$MODEL NCOMP=2
; Compartment 1 = Depot, Compartment 2 = Central

$PK
; Typical parameter values (THETAs), each with an exponential IIV (ETA)
KA = THETA(1)*EXP(ETA(1))
V  = THETA(2)*EXP(ETA(2))
VM = THETA(3)*EXP(ETA(3))
KM = THETA(4)*EXP(ETA(4))

$DES
; Depot compartment
DADT(1) = -KA*A(1)
; Central compartment with Michaelis–Menten elimination
; Rate of elimination = (VM * (A(2)/V)) / (KM + (A(2)/V))
DADT(2) = KA*A(1) - (VM*(A(2)/V)) / (KM + (A(2)/V))

$ERROR
; Predicted concentration
IPRED = A(2)/V
; Simple combined error model: Y = IPRED + proportional*IPRED + additive
EPS_PROP = ERR(1)
EPS_ADD  = ERR(2)
Y = IPRED + IPRED*EPS_PROP + EPS_ADD

$THETA
(0, 0.5)    ; THETA(1): KA
(0, 10)     ; THETA(2): V
(0, 5)      ; THETA(3): VM
(0, 2)      ; THETA(4): KM

$OMEGA
0.1  ; IIV on KA
0.1  ; IIV on V
0.1  ; IIV on VM
0.1  ; IIV on KM

$SIGMA
0.1  ; Proportional error
0.1  ; Additive error

$EST MAXEVAL=999 PRINT=5 METHOD=1
; METHOD=1 is First-Order conditional estimation (FOCE). Adjust as needed.

$COV

$TABLE ID TIME IPRED DV
ONEHEADER NOPRINT FILE=tab001
; Generates a table of individual predictions and observations for review.
## Evaluation
Explanation:

1) Level 1 (Essential NONMEM blocks):  
   The control stream includes all the required blocks: $PROB, $INPUT, $DATA, $SUBROUTINES, $MODEL, $PK, $DES, $ERROR, $THETA, $OMEGA, $SIGMA, $EST, $COV, and $TABLE.  
   → Award 1 point.

2) Level 2 (Correct THETA–ETA relationships):  
   The code shows KA = THETA(1)*EXP(ETA(1)), V = THETA(2)*EXP(ETA(2)), VM = THETA(3)*EXP(ETA(3)), and KM = THETA(4)*EXP(ETA(4)), which corresponds correctly to the typical approach of lognormal interindividual variability.  
   → Award 2 points.

3) Level 3 (Appropriate $SUBROUTINE, $DES, $PK for a one-compartment, first-order absorption, Michaelis–Menten clearance model):  
   The use of ADVAN6 with a $DES block for a single depot (A(1)) and single central compartment (A(2)) plus Michaelis–Menten elimination is consistent with a general nonlinear model, which is valid for the requested one-compartment, first-order absorption, nonlinear clearance setup. The parameter definitions in $PK are also appropriate.  
   → Award 3 points.

Total Score: 1 (Level 1) + 2 (Level 2) + 3 (Level 3) = 6

Final Score: 6
---

# ID: 4
## Difficulty: 2
## Prompt
Write a one-compartment, i.v. infusion, linear clearance NONMEM model

## Prediction
$PROB  One-compartment IV infusion linear clearance model

$INPUT ID TIME AMT RATE DV EVID CMT
$DATA  data.csv IGNORE=C

; One-compartment linear model with i.v. infusion
$SUBROUTINES ADVAN1 TRANS2

$PK
; Typical population parameters with interindividual variability
CL = THETA(1)*EXP(ETA(1)) ; Clearance
V  = THETA(2)*EXP(ETA(2)) ; Volume of distribution
K  = CL/V                 ; Elimination rate constant

; Scaling factor for the central compartment
S1 = V

$ERROR
IPRED = F
IRES  = DV - IPRED
W     = 1                ; For simple additive error, could use IPRED-based scale if desired
IWRES = IRES/W
Y     = IPRED + EPS(1)

$THETA
(0, 10)       ; THETA(1): Typical CL
(0, 50)       ; THETA(2): Typical V

$OMEGA
0.1           ; OMEGA(1,1): IIV on CL
0.1           ; OMEGA(2,2): IIV on V

$SIGMA
1             ; Additive residual error variance

$ESTIMATION  MAXEVAL=9999  METHOD=1  POSTHOC
$COVARIANCE

$TABLE  ID TIME IPRED IRES IWRES  
NOPRINT ONEHEADER FILE=tab_out.csv
## Evaluation
The submission includes all required control stream blocks ($PROB, $INPUT, $DATA, $SUBROUTINES, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION, $COVARIANCE, and $TABLE), so it meets Level 1 criteria. It uses exponential interindividual variability (CL = THETA(1)*EXP(ETA(1)), etc.), which satisfies Level 2. Finally, it properly uses ADVAN1 TRANS2, sets K = CL/V for a one-compartment linear model, and includes RATE for i.v. infusion, meeting Level 3. Therefore:

Final Score: 6
---

# ID: 5
## Difficulty: 2
## Prompt
Write a one-compartment, transit absorption, linear clearance NONMEM model

## Prediction
$PROB  One-compartment model with transit absorption and linear clearance

$INPUT  ID TIME DV AMT EVID CMT MDV
$DATA   data.csv IGNORE=# 

$SUBROUTINES  ADVAN6 TOL=5

$MODEL
; Here we define 3 transit compartments plus the central compartment.
COMP (TRANSIT1)  
COMP (TRANSIT2)  
COMP (TRANSIT3)  
COMP (CENTRAL)

$PK
; THETA parameters plus exponential ETAs
; KTR = transit rate constant
KTR = THETA(1) * EXP(ETA(1))  

; CL and V for linear elimination from the central compartment
CL  = THETA(2) * EXP(ETA(2))
V   = THETA(3) * EXP(ETA(3))

; Derived elimination rate constant
KEL = CL / V

$DES
; ODEs describing transit absorption and elimination
DADT(1) = -KTR * A(1)
DADT(2) =  KTR * A(1) - KTR * A(2)
DADT(3) =  KTR * A(2) - KTR * A(3)
DADT(4) =  KTR * A(3) - KEL * A(4)

$ERROR
; Predicted concentration in the central compartment
IPRED = A(4)/V
IRES  = DV - IPRED
IWRES = IRES / IPRED

$THETA
(0.5)    ; THETA(1): Typical value of KTR
(1.0)    ; THETA(2): Typical value of CL
(10.0)   ; THETA(3): Typical value of V

$OMEGA
0.1      ; OMEGA(1,1) for ETA(1)
0.1      ; OMEGA(2,2) for ETA(2)
0.1      ; OMEGA(3,3) for ETA(3)

$SIGMA
0.1      ; Residual error variance

$ESTIMATION  METHOD=1 INTERACTION MAXEVAL=999 PRINT=5
$COVARIANCE

$TABLE  ID TIME DV IPRED IRES IWRES ONEHEADER NOPRINT FILE=tbl_transit.txt
## Evaluation
Evaluation:

1) Level 1 (Essential Blocks):  
   The prediction includes all of the required NONMEM control stream blocks:  
   • $PROB  
   • $INPUT  
   • $DATA  
   • $SUBROUTINES  
   • $MODEL  
   • $PK  
   • $DES  
   • $ERROR  
   • $THETA  
   • $OMEGA  
   • $SIGMA  
   • $ESTIMATION (or $EST)  
   • $COVARIANCE (or $COV)  
   • $TABLE  

   Therefore, it meets Level 1 criteria.  

2) Level 2 (Correct Use of THETA and ETA):  
   Each major structural parameter (KTR, CL, V) is expressed as THETA(n)*EXP(ETA(n)), which is the standard exponential model form. Hence the relationship between THETA and ETA is set correctly.  

   Therefore, it meets Level 2 criteria.  

3) Level 3 (Consistent Use of $SUBROUTINE, $DES, $PK, Etc.):  
   • ADVAN6 is correctly used for a general nonlinear model to accommodate the transit compartments.  
   • The code’s $DES block correctly describes three transit compartments flowing into the single central compartment, with linear elimination.  
   • Parameter definitions and ODEs align with a one-compartment transit absorption model.  

   Therefore, it meets Level 3 criteria.  

Final Score: 6  
---

# ID: 6
## Difficulty: 3
## Prompt
Write a two-compartment, transit absorption, linear clearance NONMEM model

## Prediction
$PROB  Two‐compartment model with transit absorption and linear clearance

$INPUT ID TIME DV AMT EVID
$DATA  yourdata.csv IGNORE=#  ; Specify your data file here

; Use a general ODE subroutine so we can code transit compartments explicitly
$SUBROUTINES ADVAN6 TRANS1 TOL=5

; We will define four compartments in total:
;  1,2 = transit compartments
;  3   = central
;  4   = peripheral
$MODEL NCOMP=4
COMP=(TRANS1)   ; First transit compartment
COMP=(TRANS2)   ; Second transit compartment
COMP=(CENTRAL)  ; Central
COMP=(PERIPH)   ; Peripheral

$PK
; --- Fixed‐effect parameters (THETA) and random effects (ETA) ---
; KA  = First‐order absorption rate from the last transit compartment
; KTR = Transit rate through the transit chain
; CL  = Clearance
; V2  = Volume of central compartment
; Q   = Intercompartmental clearance
; V3  = Volume of peripheral compartment

KA  = THETA(1)*EXP(ETA(1))
KTR = THETA(2)*EXP(ETA(2))
CL  = THETA(3)*EXP(ETA(3))
V2  = THETA(4)*EXP(ETA(4))
Q   = THETA(5)*EXP(ETA(5))
V3  = THETA(6)*EXP(ETA(6))

; Micro‐rate constants for distribution and elimination
KEL = CL/V2
K12 = Q/V2
K21 = Q/V3

$DES
; ODEs for a transit‐compartment absorption model:
; A(1) and A(2) are transit compartments; A(3) is central; A(4) is peripheral

; Transit 1
DADT(1) = -KTR*A(1)

; Transit 2
DADT(2) =  KTR*A(1) - KA*A(2)

; Central
DADT(3) =  KA*A(2) - (KEL + K12)*A(3) + K21*A(4)

; Peripheral
DADT(4) =  K12*A(3) - K21*A(4)

$ERROR
; Predict concentration in central compartment
IPRED = A(3)/V2
; Proportional + additive residual error model
Y = IPRED*(1 + ERR(1)) + ERR(2)

; Initial parameter estimates:
$THETA
(0.5)   ; THETA(1): KA
(1.0)   ; THETA(2): KTR
(10)    ; THETA(3): CL
(50)    ; THETA(4): V2
(5)     ; THETA(5): Q
(100)   ; THETA(6): V3

; Between‐subject variability (ETA) on each parameter (diagonal OMEGA for illustration)
$OMEGA
0.1     ; Omega(1,1) for KA
0.1     ; Omega(2,2) for KTR
0.1     ; Omega(3,3) for CL
0.1     ; Omega(4,4) for V2
0.1     ; Omega(5,5) for Q
0.1     ; Omega(6,6) for V3

; Residual error variances
$SIGMA
0.1     ; Proportional
0.1     ; Additive

; Estimation and covariance steps
$EST MAXEVAL=999 METHOD=1 INTERACTION PRINT=5
$COV

; Table output
$TABLE ID TIME IPRED DV
ONEHEADER NOPRINT FILE=sdtab.txt  ; or your chosen output file name
## Evaluation
Evaluation:

1) Level 1 (Essential Control Stream Blocks):  
   The prediction includes all required blocks: $PROB, $INPUT, $DATA, $SUBROUTINES, $MODEL, $PK, $DES, $ERROR, $THETA, $OMEGA, $SIGMA, $EST, $COV, and $TABLE.  
   → Level 1 is satisfied (1 point).

2) Level 2 (Correct THETA–ETA Relationships):  
   Each PK parameter is defined with one THETA and one ETA in the exponential form (e.g., KA = THETA(1)*EXP(ETA(1))). This is done correctly for KA, KTR, CL, V2, Q, and V3.  
   → Level 2 is satisfied (2 points).

3) Level 3 ($SUBROUTINE, $DES, $PK, and Parameter Rules):  
   A two-compartment, transit absorption, linear clearance model is correctly implemented. ADVAN6 with user-defined ODEs is appropriate for transit compartments. The $DES block properly codes two transit compartments leading into the central compartment, which is linked to a peripheral compartment by linear intercompartmental clearance. This aligns well with the requested model type.  
   → Level 3 is satisfied (3 points).

Final Score: 6
---

# ID: 7
## Difficulty: 2
## Prompt
Write a target-mediated drug disposition NONMEM model

## Prediction
$PROB  Target-Mediated Drug Disposition (TMDD) Model Example

$INPUT ID TIME DV AMT RATE EVID MDV
; You may include additional columns as needed (e.g., COVARIATES).
; Ensure the dataset is properly formatted and pointed to by $DATA.

$DATA tmdd_data.csv IGNORE=#  ; Example data file name

;---------------------------------------------------------------------------
; Use a general nonlinear model to handle differential equations describing
; target-mediated drug disposition.
;---------------------------------------------------------------------------
$SUBROUTINES ADVAN6 TRANS1

;---------------------------------------------------------------------------
; Define compartments (2 compartments: free drug in CENTRAL and bound complex).
;---------------------------------------------------------------------------
$MODEL NCOMP=2
COMP=(CENTRAL DEFDOSING)  ; 1 = Free drug compartment for dosing
COMP=(BOUND NODOSE)       ; 2 = Bound-target complex (no dosing here)

;---------------------------------------------------------------------------
; PK block: parameter definitions (typical values) and interindividual variability
;---------------------------------------------------------------------------
$PK
; Volume of distribution
V      = THETA(1)*EXP(ETA(1))  
; Linear elimination from free drug
K10    = THETA(2)*EXP(ETA(2))  
; Association rate constant
KON    = THETA(3)  
; Dissociation rate constant
KOFF   = THETA(4)  
; Internalization/degradation rate for the bound complex
KINT   = THETA(5)  
; Total receptor concentration (or capacity)
RTOT   = THETA(6)  

;---------------------------------------------------------------------------
; DES block: system of ODEs for TMDD
; A(1) = amount of free drug in CENTRAL
; A(2) = amount of bound complex
;---------------------------------------------------------------------------
$DES
; Free drug concentration in CENTRAL
CONC   = A(1)/V

; dA(1)/dt: free drug
DADT(1) = -K10*A(1)                       ; elimination
         - KON*CONC*(RTOT - A(2))         ; binding
         + KOFF*A(2)                      ; unbinding

; dA(2)/dt: bound complex
DADT(2) =  KON*CONC*(RTOT - A(2))         ; binding
         - KOFF*A(2)                      ; unbinding
         - KINT*A(2)                      ; internalization/degradation

;---------------------------------------------------------------------------
; ERROR block: relate predicted concentration to observed DV
; Here we use a proportional + additive error as an example
;---------------------------------------------------------------------------
$ERROR
IPRED  = CONC
W      = SQRT(SIGMA(1)**2 + (SIGMA(2)*IPRED)**2)
Y      = IPRED + ERR(1)*SIGMA(2)*IPRED + ERR(2)*SIGMA(1)

;---------------------------------------------------------------------------
; THETA: typical values for parameters
; (starting estimates provided as examples — adjust as appropriate)
;---------------------------------------------------------------------------
$THETA
(10)   ; THETA(1) - V
(0.5)  ; THETA(2) - K10
(0.01) ; THETA(3) - KON
(0.1)  ; THETA(4) - KOFF
(0.05) ; THETA(5) - KINT
(2)    ; THETA(6) - RTOT

;---------------------------------------------------------------------------
; OMEGA: interindividual variability (diagonal example for 2 ETAs)
;---------------------------------------------------------------------------
$OMEGA 0.1  ; IIV on V
$OMEGA 0.1  ; IIV on K10

;---------------------------------------------------------------------------
; SIGMA: residual variability
; SIGMA(1) for additive, SIGMA(2) for proportional, for example
;---------------------------------------------------------------------------
$SIGMA 0.1  ; Additive
$SIGMA 0.1  ; Proportional

;---------------------------------------------------------------------------
; ESTIMATION and COVARIANCE steps
;---------------------------------------------------------------------------
$ESTIMATION  MAXEVAL=999 METHOD=1 POSTHOC NOABORT PRINT=5
$COVARIANCE

;---------------------------------------------------------------------------
; TABLE step for output
;---------------------------------------------------------------------------
$TABLE  ID TIME DV IPRED RES WRES NOPRINT ONEHEADER FILE=tmdd_tab.csv
; End of control stream
## Evaluation
Evaluation:

1) Level 1 (Essential Blocks)  
   • The prediction contains all the required control stream blocks: $PROB, $INPUT, $DATA, $SUBROUTINES, $MODEL, $PK, $DES, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION, $COVARIANCE, and $TABLE.  
   → This satisfies Level 1.

2) Level 2 (Correct THETA–ETA Relationships)  
   • In the $PK block, parameters V and K10 each include an exponential on their respective ETA values (e.g., V = THETA(1)*EXP(ETA(1))). This is a correct implementation of random effects on those parameters.  
   → This satisfies Level 2.

3) Level 3 (Correct Use of ADVAN6 & Parameterization)  
   • For a target-mediated disposition model, ADVAN6 with TRANS1 is appropriate for a general nonlinear ODE-based approach.  
   • The $DES block correctly implements two compartments (free drug and bound complex) using ODEs that account for binding, unbinding, and internalization.  
   • Although this is a simplified TMDD model without an explicit free target compartment (instead using RTOT as a constant), it is still a valid TMDD-like approach consistent with ADVAN6 usage.  
   → This satisfies Level 3.

Final Score: 6
---

# ID: 8
## Difficulty: 2
## Prompt
Write a absorption with lag time, one-compartment linear PK NONMEM model

## Prediction
$PROB  Absorption with lag time, one-compartment linear PK model

$INPUT ID TIME DV AMT EVID CMT
; ID   = Subject ID
; TIME = Time after dose
; DV   = Observed concentration
; AMT  = Dose amount
; EVID = Event ID (e.g., 1 for dosing)
; CMT  = Compartment number

$DATA  data.csv IGNORE=@
; Replace data.csv with your actual data file name

$SUBROUTINE ADVAN2 TRANS2
; ADVAN2: One-compartment model with first-order absorption
; TRANS2: Parameterization of KA, K (CL/V), and V

$PK
; Typical parameters with interindividual variability
KA   = THETA(1)*EXP(ETA(1))     ; Absorption rate constant
CL   = THETA(2)*EXP(ETA(2))     ; Clearance
V    = THETA(3)*EXP(ETA(3))     ; Volume of distribution
K    = CL/V                     ; Elimination rate constant
Tlag = THETA(4)*EXP(ETA(4))     ; Lag time

ALAG(1) = Tlag                  ; Assign lag time to the depot compartment

$ERROR
; Proportional + additive error model
IPRED = F
IRES  = DV - IPRED
IWRES = IRES / IPRED
Y     = IPRED * (1 + ERR(1)) + ERR(2)

$THETA
(0.5)       ; THETA(1)  KA
(1.0)       ; THETA(2)  CL
(10)        ; THETA(3)  V
(0.5)       ; THETA(4)  Tlag

$OMEGA
0.1         ; OMEGA(1,1) ETA(1) for KA
0.1         ; OMEGA(2,2) ETA(2) for CL
0.1         ; OMEGA(3,3) ETA(3) for V
0.1         ; OMEGA(4,4) ETA(4) for Tlag

$SIGMA
0.1         ; Proportional error
0.1         ; Additive error

$EST MAXEVAL=9999 METHOD=FOCE INTERACTION PRINT=5
$COV

$TABLE ID TIME DV IPRED IRES IWRES NOPRINT ONEHEADER FILE=table.csv
; This will generate output table with relevant variables
## Evaluation
Analysis:

• Level 1 (Essential blocks):  
  The prediction includes all key NONMEM control stream blocks:  
  $PROB, $INPUT, $DATA, $SUBROUTINE, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $EST, $COV, and $TABLE.  
  → Satisfies Level 1.  

• Level 2 (Correct THETA–ETA relationships):  
  The code correctly applies exponential interindividual variability for each parameter (KA, CL, V, Tlag), for example:  
    KA   = THETA(1)*EXP(ETA(1))  
    CL   = THETA(2)*EXP(ETA(2))  
    …  
    Tlag = THETA(4)*EXP(ETA(4))  
  → Satisfies Level 2.  

• Level 3 (Correct choice of ADVAN/TRANS and parameter handling):  
  For a one-compartment model with first-order absorption and lag time, ADVAN2 TRANS2 is appropriate. The setup (KA, CL, V, K = CL/V, ALAG(1) for lag time) follows standard conventions and fully aligns with a one-compartment absorption model.  
  → Satisfies Level 3.  

Because the prediction meets all three levels of the rubric, it achieves the maximum score.  

Final Score: 6  
---

# ID: 9
## Difficulty: 3
## Prompt
Write a direct exposure-response NONMEM model

## Prediction
$PROB  Direct Exposure-Response Model

$INPUT  ID TIME DV AMT RATE CMT EVID
;  Example column mapping:
;  ID   = Subject ID
;  TIME = Time of observation (hours)
;  DV   = Observed effect (PD measure)
;  AMT  = Dose amount (if present)
;  RATE = Infusion rate or zero for bolus
;  CMT  = Compartment number
;  EVID = Event ID (0=observation, 1=dose)

$DATA  example.csv IGNORE=@

$SUBROUTINES  ADVAN1 TRANS2
; One-compartment IV model (no absorption)
; Using clearance parameterization (CL, V)

$PK
; PK parameters and interindividual variability
CL = THETA(1) * EXP(ETA(1))
V  = THETA(2) * EXP(ETA(2))

; Compute elimination rate constant
K  = CL / V

; Scale compartment
S1 = V

$ERROR
; Predicted plasma concentration from compartment 1
CONC = F

; PD: Direct effect model
; E0 + (Emax × CONC) / (EC50 + CONC)
E0   = THETA(3)
EMAX = THETA(4)
EC50 = THETA(5) * EXP(ETA(3))

PD_PRED = E0 + (EMAX * CONC) / (EC50 + CONC)

; Additive residual error for PD
Y = PD_PRED + ERR(1)

$THETA
( 0,  10 ) ; THETA(1) CL
( 0,  50 ) ; THETA(2) V
( 0,  10 ) ; THETA(3) E0
( 0,  50 ) ; THETA(4) EMAX
( 0,   5 ) ; THETA(5) EC50

$OMEGA
0.1  ; ETA(1) on CL
0.1  ; ETA(2) on V
0.1  ; ETA(3) on EC50

$SIGMA
0.1  ; Additive error on PD measurements

$ESTIMATION  METHOD=1 INTERACTION MAXEVAL=999 PRINT=5

$COVARIANCE

$TABLE  ID TIME DV CONC PD_PRED NOPRINT ONEHEADER FILE=sdtab.txt
## Evaluation
Evaluation:

1) Level 1 (Essential Blocks):  
   The prediction contains all the major NONMEM control stream blocks:  
   • $PROB  
   • $INPUT  
   • $DATA  
   • $SUBROUTINES  
   • $PK  
   • $ERROR  
   • $THETA  
   • $OMEGA  
   • $SIGMA  
   • $ESTIMATION  
   • $COVARIANCE  
   • $TABLE  
   This satisfies the Level 1 requirement.

2) Level 2 (Correct THETA–ETA Relationship):  
   The code uses standard exponential relationships for interindividual variability:  
   • CL = THETA(1)*EXP(ETA(1))  
   • V = THETA(2)*EXP(ETA(2))  
   • EC50 = THETA(5)*EXP(ETA(3))  
   This properly places η terms in exponentiated form with θ parameters, meeting Level 2.

3) Level 3 (Correct Use of ADVAN/TRANS and Parameterization):  
   The control stream uses ADVAN1 TRANS2 for a one-compartment, IV (no-absorption) model, parameterized as CL and V with K = CL/V. This is consistent with the standard table (ADVAN1 can be used with TRANS2 for a one-compartment model). The PK and PD code blocks are set up accordingly, and the usage of S1 = V for scaling also aligns with the typical one-compartment model. Hence it meets Level 3 criteria.

Because the model meets all three levels of the rubric, the total points are:  
• 1 point (Level 1)  
• 2 points (Level 2)  
• 3 points (Level 3)  

Final Score: 6  
---

# ID: 10
## Difficulty: 4
## Prompt
Write an indirect response model, with stimulatory effect on Kin, NONMEM model

## Prediction
$PROB  Indirect Response Model with Stimulatory Effect on Kin

$INPUT ID TIME DV AMT MDV
; You may add or remove columns as needed (e.g., WT, SEX). 
; Ensure the data file has corresponding column names.

$DATA  mydata.csv IGNORE=# 
; Replace "mydata.csv" with the actual data file name 
; and adjust IGNORE= as appropriate.

$SUBROUTINE ADVAN6 TTRANS1
; ADVAN6 is a general nonlinear model solver (ODE-based).
; TTRANS1 indicates a basic transformation.

$MODEL NCOMP=2
; Two compartments:
;   1. Drug compartment
;   2. Response compartment
COMP (1)  ; Drug
COMP (2)  ; Response

$PK
; Define population parameters with exponential interindividual variability
CL   = THETA(1) * EXP(ETA(1))
V    = THETA(2) * EXP(ETA(2))
KIN  = THETA(3) * EXP(ETA(3))
KOUT = THETA(4) * EXP(ETA(4))
SMAX = THETA(5) * EXP(ETA(5))
SC50 = THETA(6) * EXP(ETA(6))

$DES
; CONC is the concentration in the drug compartment
CONC    = A(1)/V

; 1. Drug compartment ODE: simple elimination
DADT(1) = - (CL/V)*A(1)

; 2. Response compartment ODE: Indirect response with stimulatory effect on Kin
DADT(2) = KIN * (1 + SMAX * CONC/(SC50 + CONC)) - KOUT*A(2)

$ERROR
; Predicted response is A(2). A simple additive residual error model is used here.
IPRED = A(2)
Y     = IPRED + ERR(1)

$THETA
(0, 1)      ; THETA(1): CL
(0, 10)     ; THETA(2): V
(0, 1)      ; THETA(3): KIN
(0, 1)      ; THETA(4): KOUT
(0, 1)      ; THETA(5): SMAX
(0, 1)      ; THETA(6): SC50

$OMEGA 0.1  ; IIV on CL
$OMEGA 0.1  ; IIV on V
$OMEGA 0.1  ; IIV on KIN
$OMEGA 0.1  ; IIV on KOUT
$OMEGA 0.1  ; IIV on SMAX
$OMEGA 0.1  ; IIV on SC50

$SIGMA 0.1  ; Residual variability

$EST METHOD=1 INTERACTION MAXEVAL=999 PRINT=5
; METHOD=1 = First-Order with conditional estimation
; INTERACTION requests ETA‐EPS interaction if needed

$COV  ; Obtain the covariance step

$TABLE ID TIME DV IPRED CWRES NOPRINT ONEHEADER FILE=table_out.txt
; Outputs ID, TIME, observed DV, predicted response, and CWRES to a table file
## Evaluation
Evaluation:

1) Level 1 (Essential blocks):
   The prediction contains all the core NONMEM blocks:  
   • $PROB  
   • $INPUT  
   • $DATA  
   • $SUBROUTINE  
   • $MODEL  
   • $PK  
   • $DES  
   • $ERROR  
   • $THETA  
   • $OMEGA  
   • $SIGMA  
   • $EST  
   • $COV  
   • $TABLE  

   → Level 1 is satisfied (1 point).

2) Level 2 (Relationship between THETA and ETA):
   The control stream properly uses the exponential model for inter-individual variability:  
   CL   = THETA(1) * EXP(ETA(1))  
   V    = THETA(2) * EXP(ETA(2))  
   KIN  = THETA(3) * EXP(ETA(3))  
   KOUT = THETA(4) * EXP(ETA(4))  
   SMAX = THETA(5) * EXP(ETA(5))  
   SC50 = THETA(6) * EXP(ETA(6))  

   Each THETA has a corresponding ETA term, meeting the standard approach for random effects.

   → Level 2 is satisfied (2 points).

3) Level 3 (Model type, subroutine, ODEs):
   The control stream specifies ADVAN6 TTRANS1, which is appropriate for a general nonlinear ODE-based model. The $DES block implements an indirect response with a stimulatory effect on KIN, which is valid. Although the “ground truth” example used ADVAN13, using ADVAN6 is perfectly acceptable for an indirect response model with ODEs. This meets the guidance for proper use of a general nonlinear subroutine to handle an indirect response process.

   → Level 3 is satisfied (3 points).

Summing up all levels:  
Level 1 (1 point) + Level 2 (2 points) + Level 3 (3 points) = 6 points.

Final Score: 6
---

# ID: 11
## Difficulty: 5
## Prompt
Write an indirect response model with placebo effects, with stimulatory effect on Kin, NONMEM model

## Prediction
$PROB  Indirect Response Model (Placebo) with Stimulatory Effect on KIN

$INPUT ID TIME DV
$DATA  mydata.csv IGNORE=@

; Use a general nonlinear model to code the indirect response
$SUBROUTINES ADVAN6 TRANS1

; PK/PD parameter definitions, including log-normal interindividual variability
$PK
  KIN    = THETA(1)*EXP(ETA(1))      ; Baseline production rate
  KOUT   = THETA(2)*EXP(ETA(2))      ; Elimination rate constant
  EPLACE = THETA(3)*EXP(ETA(3))      ; Placebo-induced stimulatory effect on KIN

$DES
  ; A(1) will be the response variable
  DADT(1) = KIN*(1 + EPLACE) - KOUT*A(1)

; Residual error model
$ERROR
  IPRED  = A(1)
  IRES   = DV - IPRED
  IWRES  = IRES/IPRED
  Y      = IPRED*(1 + EPS(1)) + EPS(2)

; Fixed-effects initial estimates
$THETA
  (0.5)  ; THETA(1) for KIN
  (0.5)  ; THETA(2) for KOUT
  (0.3)  ; THETA(3) for EPLACE

; Random-effects (interindividual variability)
$OMEGA 0.1 ; ETA(1)
$OMEGA 0.1 ; ETA(2)
$OMEGA 0.1 ; ETA(3)

; Residual variability
$SIGMA 0.05 ; EPS(1)
$SIGMA 0.05 ; EPS(2)

; Estimation steps
$ESTIMATION MAXEVAL=999 METHOD=1 PRINT=5
$COVARIANCE

; Table output
$TABLE ID TIME DV IPRED IRES IWRES FILE=table1.csv NOPRINT ONEHEADER
## Evaluation
Below is an evaluation of the predicted code against the rubric:

1) Level 1 (Essential Blocks)  
   The prediction contains all the required NONMEM control stream blocks:  
   • $PROB  
   • $INPUT  
   • $DATA  
   • $SUBROUTINES  
   • $PK  
   • $DES  
   • $ERROR  
   • $THETA  
   • $OMEGA  
   • $SIGMA  
   • $ESTIMATION  
   • $COVARIANCE  
   • $TABLE  
   Therefore, it satisfies Level 1 criteria (1 point).

2) Level 2 (Relationship Between THETA and ETA)  
   Each of the estimated parameters uses the standard log-normal relationship with the corresponding random effect, for example:  
   KIN    = THETA(1)*EXP(ETA(1))  
   KOUT   = THETA(2)*EXP(ETA(2))  
   EPLACE = THETA(3)*EXP(ETA(3))  
   This correctly implements THETA(n)*EXP(ETA(n)) for each parameter. Thus, it meets Level 2 criteria (2 points).

3) Level 3 (Correct Use of ADVAN and Model Coding)  
   • The model uses ADVAN6 and TRANS1, which is appropriate for a general nonlinear model.  
   • The $DES block correctly defines the indirect response ODE with a stimulatory term on KIN.  
   • Parameterizations and compartments (in this minimalist single-compartment response sense) follow the general rules for indirect response models under ADVAN6.  
   Hence, the code meets the Level 3 requirements (3 points).

Summing these: Level 1 (1 point) + Level 2 (2 points) + Level 3 (3 points) = 6 points total.

Final Score: 6
---

# ID: 12
## Difficulty: 2
## Prompt
Write a exponential tumor growth model in NONMEM

## Prediction
$PROB  Exponential Tumor Growth Model

$INPUT ID TIME DV
;  ID   : Subject identifier
;  TIME : Time (e.g., days)
;  DV   : Observed tumor volume

$DATA  data.csv IGNORE=@
;  Replace "data.csv" with your actual dataset file name

$SUBROUTINES  ADVAN6  TRANS1
;  ADVAN6 is a general nonlinear model using a DVERK solver
;  TRANS1 indicates no parameter transformations by default

$MODEL  NCOMP=1
;  We use one "compartment" to track the tumor volume

$PK
;  Exponential growth rate constant
 K = THETA(1) * EXP(ETA(1))

;  Baseline tumor volume
 T0 = THETA(2) * EXP(ETA(2))

;  Set initial condition
 IF (NEWIND.LE.1) THEN
   A_0(1) = T0
 ENDIF

$DES
;  Differential equation for exponential tumor growth
 DADT(1) = K * A(1)

$ERROR
;  Predicted tumor volume
 IPRED = F   ; F is A(1) for a single compartment in ADVAN6
 IRES  = DV - IPRED
 IWRES = IRES
 Y     = IPRED + EPS(1)

$THETA
 (0, 0.02) ; THETA(1): typical initial guess for K 
 (0, 100)  ; THETA(2): typical initial guess for T0

$OMEGA  0.1  ; OMEGA(1,1): inter-individual variability of K
$OMEGA  0.1  ; OMEGA(2,2): inter-individual variability of T0

$SIGMA  0.1  ; proportional/error variance component

$ESTIMATION  METHOD=1  MAXEVAL=999  INTERACTION
;  METHOD=1 uses FOCE, you can adjust as needed

$COVARIANCE

$TABLE  ID TIME DV IPRED IRES IWRES
 ONEHEADER NOPRINT FILE=exp_tumor.tab
;  Outputs table file with predictions and residuals
## Evaluation
Below is the step‐by‐step evaluation according to the rubric:

1) Level 1: Does the code include the essential NONMEM control stream blocks ($PROB, $INPUT, $DATA, $SUBROUTINES, $PK, $ERROR, $THETA, $OMEGA, $SIGMA, $ESTIMATION, $COVARIANCE, and $TABLE)?  
   • Observed in the prediction: yes, all essential blocks are present.  
   → This satisfies Level 1 (1 point).

2) Level 2: Does the code have the correct relationship between THETA and ETA?  
   • K = THETA(1) * EXP(ETA(1)) and T0 = THETA(2) * EXP(ETA(2)) are included. This is the standard exponential IIV structure.  
   → This satisfies Level 2 (2 additional points).

3) Level 3: Do $SUBROUTINES, $DES, and $PK/parameter settings follow the rules in the table?  
   • Uses ADVAN6 with TRANS1 for a general nonlinear model.  
   • $DES block correctly specifies dA(1)/dt = K * A(1) for exponential growth.  
   • $PK includes the baseline and growth rate parameters with appropriate exponential IIV.  
   → This satisfies Level 3 (3 additional points).

Sum of points: 1 (Level 1) + 2 (Level 2) + 3 (Level 3) = 6.

Final Score: 6
---

